# Portal de Estudos / Simulado Detran RJ - Full package (v2)

This package includes an admin panel (demo) where the admin can change the standard price and create promotions that apply by HH:MM intervals (America/Sao_Paulo timezone).

Admin credentials (demo):
- Email: mauricio2santosmarcolino@gmail.com
- Password: Admin@2025

Deployment suggestions:
- Frontend: Vercel
- Backend: Render (or Railway)
- In production, replace local storage.json with a database (MongoDB Atlas, Supabase, Postgres).

Files included:
- backend/ -> Express server (index.js, package.json, .env.example, storage.json)
- frontend/ -> Vite + React (src, package.json)
- vercel.json, render.yaml

Quick start (local):
1. Backend: copy backend/.env.example to backend/.env and fill MP_ACCESS_TOKEN and JWT_SECRET
2. `cd backend && npm install && npm run dev`
3. Frontend: `cd frontend && npm install && npm run dev`
