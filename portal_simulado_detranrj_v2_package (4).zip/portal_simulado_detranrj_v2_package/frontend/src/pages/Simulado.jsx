import React,{useState} from 'react'
const SAMPLE = [{id:1,q:'Velocidade máxima em área urbana?', opts:['60','50','40'], correct:1},{id:2,q:'Placa vermelha significa?', opts:['Obrigação','Proibido','Alerta'], correct:1}]
export default function Simulado(){
  const [ans,setAns]=useState({}); const [submitted,setSubmitted]=useState(false); const [score,setScore]=useState(0)
  function select(q,i){ setAns(prev=>({...prev,[q]:i})) }
  function submit(){ let c=0; SAMPLE.forEach(s=>{ if(ans[s.id]===s.correct) c++}); setScore(Math.round((c/SAMPLE.length)*100)); setSubmitted(true) }
  return (<div className="card"><h2>Simulado (demo)</h2>{SAMPLE.map(s=> (<div key={s.id}><p>{s.id}. {s.q}</p>{s.opts.map((o,idx)=>(<label key={idx}><input type="radio" name={'q'+s.id} onChange={()=>select(s.id,idx)} /> {o}</label>))}</div>))}{!submitted?<button className="btn" onClick={submit}>Enviar</button>:<p>Sua nota: {score}%</p>}</div>)
}