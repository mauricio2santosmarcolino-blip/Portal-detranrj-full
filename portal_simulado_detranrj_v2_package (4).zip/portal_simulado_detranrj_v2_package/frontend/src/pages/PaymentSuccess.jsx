import React from 'react'
export default function PaymentSuccess(){ return <div className="card"><h2>Pagamento aprovado</h2><p>Obrigado! Seu pagamento foi confirmado.</p></div> }