import React, {useEffect, useState} from 'react'
import axios from 'axios'
export default function Home(){ 
  const [price, setPrice] = useState(null)
  useEffect(()=>{ async function load(){ try{ const resp = await axios.get((process.env.VITE_API_URL||'http://localhost:4000') + '/api/health') ; setPrice('R$29,90') }catch(e){ setPrice('R$29,90') } } load() },[])
  return (
  <div>
    <div className="card">
      <h1>Portal de Estudos / Simulado Detran RJ</h1>
      <p>Prepare-se para a prova com simulados no estilo do Detran-RJ. Assinatura mensal com PIX, boleto e cartão.</p>
      <a href="/signup" className="btn">Assinar Agora</a>
      <p style={{marginTop:10}}>Preço atual: <strong>{price}</strong></p>
    </div>
  </div>
)}