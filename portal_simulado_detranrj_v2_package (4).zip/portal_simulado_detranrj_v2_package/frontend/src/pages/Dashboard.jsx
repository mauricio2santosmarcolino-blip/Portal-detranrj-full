import React from 'react'
export default function Dashboard(){
  const user = JSON.parse(localStorage.getItem('user')||'null')
  if(!user) return <div className="card"><p>Você precisa entrar.</p></div>
  return <div className="card"><h2>Olá, {user.name}</h2><p>Área do aluno (demo).</p></div>
}