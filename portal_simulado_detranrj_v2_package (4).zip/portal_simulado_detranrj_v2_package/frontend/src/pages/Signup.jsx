import React, { useState, useEffect } from 'react'
import axios from 'axios'
export default function Signup(){
  const API = process.env.VITE_API_URL || 'http://localhost:4000'
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [qr, setQr] = useState(null)
  const [amount, setAmount] = useState(null)
  async function handlePix(e){
    e.preventDefault()
    const resp = await axios.post(API + '/api/create_pix_payment', { name, email })
    setQr(resp.data.qr_code_base64 || null)
    setAmount(resp.data.amount)
  }
  async function handleCheckout(e){
    e.preventDefault()
    const resp = await axios.post(API + '/api/create_preference', { name, email })
    window.location.href = resp.data.init_point
  }
  return (
    <div className="card">
      <h2>Assinar - Portal de Estudos</h2>
      <form onSubmit={handlePix}>
        <label>Nome<br/><input required value={name} onChange={e=>setName(e.target.value)} /></label><br/><br/>
        <label>E-mail<br/><input required value={email} onChange={e=>setEmail(e.target.value)} /></label><br/><br/>
        <button className="btn" onClick={handlePix}>Pagar com PIX</button>
        <button className="btn" style={{background:'#059669'}} onClick={handleCheckout}>Pagar com Cartão / Boleto</button>
      </form>
      {qr && <div style={{marginTop:16}}>
        <h4>Escaneie o QR Code PIX ({amount} BRL)</h4>
        <img alt="QR" src={`data:image/png;base64,${qr}`} />
        <p>O QR expira em alguns minutos. Após o pagamento, a confirmação vem via webhook.</p>
      </div>}
    </div>
  )
}