import React, {useState, useEffect} from 'react'
import axios from 'axios'
export default function AdminPanel(){
  const API = process.env.VITE_API_URL || 'http://localhost:4000'
  const [token, setToken] = useState(localStorage.getItem('token'))
  const [config, setConfig] = useState({currentPrice:29.9, promos:[]})
  const [email,setEmail]=useState('')
  const [password,setPassword]=useState('')
  useEffect(()=>{ async function load(){ if(!token) return; try{ const resp = await axios.get(API+'/api/admin/config', { headers: { Authorization: 'Bearer '+token } }); setConfig(resp.data.config) }catch(e){ } } load() },[token])
  async function login(e){
    e.preventDefault()
    try{ const resp = await axios.post(API + '/api/login', { email, password }); localStorage.setItem('token', resp.data.token); setToken(resp.data.token); window.location='/admin' }catch(err){ alert('Erro login') }
  }
  async function saveConfig(){
    try{ await axios.post(API+'/api/admin/config', config, { headers: { Authorization: 'Bearer '+token } }); alert('Config salva') }catch(err){ alert('Erro salvando') }
  }
  function addPromo(){ const p = { id: Date.now(), name: 'Nova Promo', price: 0, start: '22:00', end: '22:59' }; setConfig(prev=>({...prev, promos: [...prev.promos, p]})) }
  function removePromo(id){ setConfig(prev=>({...prev, promos: prev.promos.filter(p=>p.id!==id)})) }
  return (<div className="card">
    {!token ? (<div><h3>Admin Login</h3><form onSubmit={login}><label>Email<br/><input value={email} onChange={e=>setEmail(e.target.value)} /></label><br/><br/><label>Senha<br/><input type="password" value={password} onChange={e=>setPassword(e.target.value)} /></label><br/><br/><button className="btn">Entrar</button></form></div>) : (<div>
      <h3>Painel Admin</h3>
      <label>Preço atual<br/><input value={config.currentPrice} onChange={e=>setConfig({...config, currentPrice: e.target.value})} /></label><br/><br/>
      <h4>Promoções</h4>
      <button className="btn" onClick={addPromo}>Adicionar Promo</button>
      {config.promos.map(p=> (<div key={p.id} style={{borderTop:'1px solid #eee', paddingTop:8, marginTop:8}}><label>Nome<br/><input value={p.name} onChange={e=>setConfig({...config, promos: config.promos.map(pp=>pp.id===p.id?{...pp, name:e.target.value}:pp)})} /></label><br/><label>Preço<br/><input value={p.price} onChange={e=>setConfig({...config, promos: config.promos.map(pp=>pp.id===p.id?{...pp, price:e.target.value}:pp)})} /></label><br/><label>Start (HH:MM)<br/><input value={p.start} onChange={e=>setConfig({...config, promos: config.promos.map(pp=>pp.id===p.id?{...pp, start:e.target.value}:pp)})} /></label><br/><label>End (HH:MM)<br/><input value={p.end} onChange={e=>setConfig({...config, promos: config.promos.map(pp=>pp.id===p.id?{...pp, end:e.target.value}:pp)})} /></label><br/><button className="btn" onClick={()=>removePromo(p.id)}>Remover</button></div>))}
      <br/><br/><button className="btn" onClick={saveConfig}>Salvar Config</button>
    </div>)}
  </div>)
}