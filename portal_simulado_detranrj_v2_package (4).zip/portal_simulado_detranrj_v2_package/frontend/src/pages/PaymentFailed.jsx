import React from 'react'
export default function PaymentFailed(){ return <div className="card"><h2>Pagamento não aprovado</h2><p>Houve um problema. Tente novamente.</p></div> }