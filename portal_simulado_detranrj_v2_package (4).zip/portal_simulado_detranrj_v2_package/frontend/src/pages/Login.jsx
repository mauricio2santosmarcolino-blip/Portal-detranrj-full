import React,{useState} from 'react'
import axios from 'axios'
export default function Login(){
  const API = process.env.VITE_API_URL || 'http://localhost:4000'
  const [email,setEmail]=useState(''); const [password,setPassword]=useState('')
  async function submit(e){ e.preventDefault(); try{ const resp=await axios.post(API + '/api/login',{email,password}); localStorage.setItem('token',resp.data.token); localStorage.setItem('user',JSON.stringify(resp.data.user)); window.location='/admin' }catch(err){ alert('Erro: '+(err.response?.data?.error||err.message)) } }
  return (<div className="card"><h2>Entrar</h2><form onSubmit={submit}><label>E-mail<br/><input value={email} onChange={e=>setEmail(e.target.value)} /></label><br/><br/><label>Senha<br/><input type="password" value={password} onChange={e=>setPassword(e.target.value)} /></label><br/><br/><button className="btn">Entrar</button></form></div>)
}