import React from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom'
import Home from './pages/Home'
import Signup from './pages/Signup'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import Simulado from './pages/Simulado'
import AdminPanel from './pages/AdminPanel'
import PaymentSuccess from './pages/PaymentSuccess'
import PaymentFailed from './pages/PaymentFailed'
import './styles.css'

function App() {
  return (
    <Router>
      <div className="app">
        <header className="header">
          <Link to="/" className="brand">Portal de Estudos / Simulado Detran RJ</Link>
          <nav>
            <Link to="/simulado">Simulados</Link>
            <Link to="/signup" className="btn">Assinar</Link>
            <Link to="/admin" className="btn" style={{background:'#111'}}>Admin</Link>
          </nav>
        </header>
        <main className="container">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/signup" element={<Signup />} />
            <Route path="/login" element={<Login />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/simulado" element={<Simulado />} />
            <Route path="/admin" element={<AdminPanel />} />
            <Route path="/payment-success" element={<PaymentSuccess />} />
            <Route path="/payment-failed" element={<PaymentFailed />} />
          </Routes>
        </main>
        <footer className="footer">© {new Date().getFullYear()} Portal de Estudos / Simulado Detran RJ</footer>
      </div>
    </Router>
  )
}

createRoot(document.getElementById('root')).render(<App />)
