Frontend setup: cd frontend && npm install && npm run dev
Configure VITE_API_URL if backend not on http://localhost:4000
