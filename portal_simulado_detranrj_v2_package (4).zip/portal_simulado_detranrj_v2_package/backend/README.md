# Backend (Express) - Portal de Estudos / Simulado Detran RJ (v2)

This version includes an admin-configurable price and promotions stored in a local JSON file (storage.json).
In production, replace storage.json with a proper database (MongoDB/Postgres).

## Admin credentials (demo)
- Email: mauricio2santosmarcolino@gmail.com
- Password: Admin@2025

## Setup (local)
1. Copy `.env.example` to `.env` and fill `MP_ACCESS_TOKEN` and `JWT_SECRET`
2. `npm install`
3. `npm run dev` (or `npm start`)
