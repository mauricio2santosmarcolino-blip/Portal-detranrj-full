// backend/index.js
// Express backend with Mercado Pago PIX dynamic, preference creation, webhook handler, JWT auth, admin config persistence (memory demo)
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const mercadopago = require('mercadopago');
const jwt = require('jsonwebtoken');
const dotenv = require('dotenv');
const moment = require('moment-timezone');
const fs = require('fs');
const path = require('path');

dotenv.config();
const app = express();
app.use(cors({ origin: process.env.FRONTEND_URL || '*' }));
app.use(bodyParser.json());

// Configure Mercado Pago
if (!process.env.MP_ACCESS_TOKEN) {
  console.warn('Warning: MP_ACCESS_TOKEN not set. Place it in .env before running.');
}
mercadopago.configure({ access_token: process.env.MP_ACCESS_TOKEN || '' });

const JWT_SECRET = process.env.JWT_SECRET || 'replace_with_a_strong_secret';
const ADMIN_EMAIL = process.env.ADMIN_EMAIL || 'mauricio2santosmarcolino@gmail.com';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'Admin@2025';

// Simple storage for demo - in production use a real DB.
const storageFile = path.join(__dirname, 'storage.json');
let storage = { 
  users: [
    { id: 1, name: 'Admin', email: ADMIN_EMAIL, password: ADMIN_PASSWORD, role: 'admin' }
  ],
  subscriptions: [],
  config: {
    currentPrice: 29.9,
    promos: [
      { id: 1, name: 'Promo noite', price: 20.0, start: '22:00', end: '22:59' }
    ]
  }
};
// load storage if exists
if (fs.existsSync(storageFile)) {
  try { storage = JSON.parse(fs.readFileSync(storageFile)); } catch (e) { console.warn('Failed loading storage, using defaults'); }
} else {
  fs.writeFileSync(storageFile, JSON.stringify(storage, null, 2));
}

function saveStorage(){ fs.writeFileSync(storageFile, JSON.stringify(storage, null, 2)); }

function getPriceBRL() {
  const now = moment().tz('America/Sao_Paulo');
  const hourMinute = now.format('HH:mm');
  // Check promos
  for (const p of storage.config.promos) {
    // simple inclusive check for hour range HH:MM - HH:MM (does not handle midnight wrap)
    if (hourMinute >= p.start && hourMinute <= p.end) return p.price;
  }
  return storage.config.currentPrice;
}

app.post('/api/create_preference', async (req, res) => {
  try {
    const price = getPriceBRL();
    const { email, name } = req.body;
    const preference = {
      items: [{
        title: 'Assinatura - Portal de Estudos / Simulado Detran RJ',
        quantity: 1,
        currency_id: 'BRL',
        unit_price: Number(price),
        description: 'Assinatura mensal'
      }],
      payer: { email: email || 'payer@example.com', name: name || 'Aluno' },
      back_urls: {
        success: (process.env.FRONTEND_URL || 'http://localhost:5173') + '/payment-success',
        failure: (process.env.FRONTEND_URL || 'http://localhost:5173') + '/payment-failed',
        pending: (process.env.FRONTEND_URL || 'http://localhost:5173') + '/payment-pending'
      },
      auto_return: 'approved'
    };
    const mpResponse = await mercadopago.preferences.create(preference);
    return res.json({ init_point: mpResponse.body.init_point, preference_id: mpResponse.body.id, price });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Erro criando preferência Mercado Pago', detail: err.message });
  }
});

app.post('/api/create_pix_payment', async (req, res) => {
  try {
    const { email, name } = req.body;
    const amount = getPriceBRL();
    const paymentData = {
      transaction_amount: Number(amount),
      description: 'Assinatura - Portal de Estudos / Simulado Detran RJ',
      payment_method_id: 'pix',
      payer: { email: email || 'payer@example.com', first_name: name || 'Aluno' }
    };
    const response = await mercadopago.payment.create(paymentData);
    const { point_of_interaction, status, id } = response.body;
    const qrCode = point_of_interaction?.transaction_data?.qr_code || null;
    const qrBase64 = point_of_interaction?.transaction_data?.qr_code_base64 || null;
    storage.subscriptions.push({ id, email, amount, status, created_at: new Date().toISOString() });
    saveStorage();
    return res.json({ payment_id: id, status, qr_code: qrCode, qr_code_base64: qrBase64, amount });
  } catch (err) {
    console.error('Erro criando pagamento PIX:', err);
    return res.status(500).json({ error: 'Erro ao criar pagamento PIX', detail: err.message });
  }
});

// login (returns JWT)
app.post('/api/login', (req, res) => {
  const { email, password } = req.body;
  const user = storage.users.find(u => u.email === email && u.password === password);
  if (!user) return res.status(401).json({ error: 'Credenciais inválidas' });
  const token = jwt.sign({ id: user.id, role: user.role, name: user.name, email: user.email }, JWT_SECRET, { expiresIn: '7d' });
  return res.json({ token, user: { id: user.id, name: user.name, email: user.email, role: user.role } });
});

function authMiddleware(req, res, next) {
  const auth = req.headers['authorization'];
  if (!auth) return res.status(401).json({ error: 'Não autorizado' });
  const token = auth.split(' ')[1];
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    req.user = payload;
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Token inválido' });
  }
}

// Admin config endpoints
app.get('/api/admin/config', authMiddleware, (req, res) => {
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Acesso negado' });
  return res.json({ config: storage.config });
});

app.post('/api/admin/config', authMiddleware, (req, res) => {
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Acesso negado' });
  const { currentPrice, promos } = req.body;
  if (currentPrice !== undefined) storage.config.currentPrice = Number(currentPrice);
  if (promos !== undefined) storage.config.promos = promos;
  saveStorage();
  return res.json({ ok: true, config: storage.config });
});

app.get('/api/admin/subscriptions', authMiddleware, (req, res) => {
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Acesso negado' });
  return res.json({ subscriptions: storage.subscriptions });
});

app.post('/api/webhook/mercadopago', async (req, res) => {
  try {
    const body = req.body || {};
    // update subscription if exists
    if (body.data && body.data.id) {
      storage.subscriptions = storage.subscriptions.map(s => {
        if (s.id == body.data.id) return { ...s, status: 'approved', raw: body };
        return s;
      });
      saveStorage();
    }
    res.sendStatus(200);
  } catch (err) {
    console.error('Erro webhook:', err);
    res.sendStatus(500);
  }
});

app.get('/api/health', (req, res) => res.json({ status: 'ok' }));

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Backend running on port ${PORT}`));
